#!/bin/sh
java -mx512m -jar maxent.jar